$(document).ready(function(){
  $('.box_slider').slick({
    dots: false,  
    arrows: false,
    slidesToShow: 3,
    centerMode: true,    
    responsive: [
      {
        breakpoint: 767,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
          infinite: true          
        }
      }      
    ]
  });
});